import pygame


# Передвижение первого игрока
def first_player_right():
    first_player.y += speed_of_first_player
    if first_player.top < 0:
        first_player.top = 0
    if first_player.bottom >= height:
        first_player.bottom = height


# Передвижение второго игрока
def second_player_left():
    second_player.y += speed_of_second_player
    if second_player.top < 0:
        second_player.top = 0
    if second_player.bottom >= height:
        second_player.bottom = height


# Шар
def move_of_ball():
    global ball_speed_x, ball_speed_y, score_of_first_player, score_of_second_player, flag_for_score

    # Изменение траектории при столкновении с гор. поверхностями
    if ball.top <= 0 or ball.bottom >= height:
        ball_speed_y *= -1

    # Событие для победы в раунде первого игрока
    if ball.right >= screen_width:
        flag_for_score = pygame.time.get_ticks()
        score_of_first_player += 1
        pygame.mixer.Sound.play(score_sound)

    # Событие для победы в раунде второго игрока
    if ball.left <= 0:
        flag_for_score = pygame.time.get_ticks()
        score_of_second_player += 1
        pygame.mixer.Sound.play(score_sound)

    # Изменение траектории шара при столкновении с блоком
    if ball.colliderect(first_player) or ball.colliderect(second_player):
        ball_speed_x *= -1
        if ball_speed_x > 0 and abs(ball_speed_x) <= 15:
            ball_speed_x += 2
        elif ball_speed_x < 0 and abs(ball_speed_x) <= 15:
            ball_speed_x -= 2
        if ball_speed_y > 0 and abs(ball_speed_y) <= 15:
            ball_speed_y += 2
        elif ball_speed_y < 0 and abs(ball_speed_y) <= 15:
            ball_speed_y -= 2

    ball.x += ball_speed_x
    ball.y += ball_speed_y


# Начало нового раунда
def start_of_new_round():
    global ball_speed_x, ball_speed_y, flag_for_score, score_of_second_player, score_of_first_player, victories_of_sec,\
        victories_of_first
    ball.center = (screen_width / 2, height / 2)
    ball_speed_x = 3
    ball_speed_y = 3
    if score_of_second_player == 15:
        score_of_first_player = 0
        score_of_second_player = 0
        victories_of_sec += 1
    elif score_of_first_player == 15:
        score_of_first_player = 0
        score_of_second_player = 0
        victories_of_first += 1
    flag_for_score = False


pygame.init()
pygame.mixer.pre_init(35000, -10, 1, 1024)
clock = pygame.time.Clock()

# Настройки окна
screen_width = 1300
height = 950
screen = pygame.display.set_mode((screen_width, height))
pygame.display.set_caption("Pong: Artem's version")

# Цвет объектов
color_of_objects = (0, 0, 150)

# Объекты
second_player = pygame.Rect(screen_width - 20, height // 2, 20, 150)
first_player = pygame.Rect(0, height // 2, 20, 150)
ball = pygame.draw.circle(screen, color_of_objects, (screen_width / 2, height / 2), 20)

# Звук для победы в раунде
score_sound = pygame.mixer.Sound("bonk_of_scout.mp3")

# Стартовые значения
ball_speed_x = 0
ball_speed_y = 0
speed_of_first_player = 0
speed_of_second_player = 0
flag_for_ball = False
flag_for_score = True
running = True
score_of_first_player = 0
score_of_second_player = 0
flag_for_menu = True
x_value_for_score_of_second = 670
victories_of_first = 0
victories_of_sec = 0

# Размер шрифта для счёта, цвет счёта, цвет количества побед
font = pygame.font.Font(None, 70)
color_for_score = (255, 255, 255)
color_for_victories = (150, 0, 0)

while running:
    # Запуск функций объектов
    move_of_ball()
    first_player_right()
    second_player_left()

    # Прорисовка объектов
    screen.fill((0, 0, 0))
    pygame.draw.rect(screen, color_of_objects, first_player)
    pygame.draw.rect(screen, color_of_objects, second_player)
    pygame.draw.ellipse(screen, color_of_objects, ball)

    # Начало нового раунда
    if flag_for_score:
        start_of_new_round()

    # Прорисовка счёта
    text_of_victories_for_first_player = font.render(f'Победы: {victories_of_first}', False, color_for_victories)
    screen.blit(text_of_victories_for_first_player, (50, 50))
    text_of_victories_for_second_player = font.render(f'Победы: {victories_of_sec}', False, color_for_victories)
    screen.blit(text_of_victories_for_second_player, (950, 50))
    text_of_score_for_first_player = font.render(f'{score_of_first_player}', False, color_for_score)
    screen.blit(text_of_score_for_first_player, (560, 50))
    text_of_score_for_first_player = font.render(f'{score_of_first_player}', False, color_for_score)
    screen.blit(text_of_score_for_first_player, (560, 50))
    between_scores = font.render(':', False, color_for_score)
    screen.blit(between_scores, (615, 50))
    if score_of_second_player >= 10:
        x_value_for_score_of_second = 635
    else:
        x_value_for_score_of_second = 670
    text_of_score_for_second_player = font.render(f'{score_of_second_player}', False, color_for_score)
    screen.blit(text_of_score_for_second_player, (x_value_for_score_of_second, 50))

    # Проработка нажатий
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_o:
                speed_of_second_player -= 15
            if event.key == pygame.K_l:
                speed_of_second_player += 15
            if event.key == pygame.K_q:
                speed_of_first_player -= 15
            if event.key == pygame.K_a:
                speed_of_first_player += 15
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_o:
                speed_of_second_player += 15
            if event.key == pygame.K_l:
                speed_of_second_player -= 15
            if event.key == pygame.K_q:
                speed_of_first_player += 15
            if event.key == pygame.K_a:
                speed_of_first_player -= 15
        if event.type == pygame.QUIT:
            running = False

    clock.tick(30)
    pygame.display.flip()